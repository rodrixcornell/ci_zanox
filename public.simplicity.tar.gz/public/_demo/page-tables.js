jQuery(document).ready(function($){

  /*** DataTables ***/
  $('.datatables').dataTable();


});