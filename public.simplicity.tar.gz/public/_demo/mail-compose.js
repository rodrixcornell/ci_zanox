jQuery(document).ready(function($){

  /*** wysiwyg ***/
  tinymce.init({
    selector: "textarea#message",
    skin: "simplictiy"
  });

  });